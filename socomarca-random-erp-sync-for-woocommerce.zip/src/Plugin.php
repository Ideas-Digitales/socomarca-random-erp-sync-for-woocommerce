<?php

namespace Socomarca\RandomERP;

use Socomarca\RandomERP\Ajax\AuthAjaxHandler;
use Socomarca\RandomERP\Ajax\EntityAjaxHandler;
use Socomarca\RandomERP\Ajax\CategoryAjaxHandler;
use Socomarca\RandomERP\Ajax\ProductAjaxHandler;
use Socomarca\RandomERP\Ajax\PriceListAjaxHandler;
use Socomarca\RandomERP\Ajax\BrandAjaxHandler;
use Socomarca\RandomERP\Ajax\StockAjaxHandler;
use Socomarca\RandomERP\Ajax\WarehouseAjaxHandler;
use Socomarca\RandomERP\Ajax\CartWarehouseSwitchHandler;
use Socomarca\RandomERP\Ajax\CombinedAjaxHandler;
use Socomarca\RandomERP\Ajax\CronSyncAjaxHandler;
use Socomarca\RandomERP\Admin\AdminPages;
use Socomarca\RandomERP\Admin\CategoryTaxonomyAdmin;
use Socomarca\RandomERP\Admin\LocationMappingAdmin;
use Socomarca\RandomERP\Admin\ProductFilterAdmin;
use Socomarca\RandomERP\Ajax\LocationMappingAjaxHandler;
use Socomarca\RandomERP\Filters\CheckoutShippingFilter;
use Socomarca\RandomERP\Filters\LocationProductFilter;
use Socomarca\RandomERP\Filters\LocationStockFilter;
use Socomarca\RandomERP\Filters\ProductVisibilityFilter;
use Socomarca\RandomERP\Services\DocumentService;
use Socomarca\RandomERP\Services\CronSyncService;
use Socomarca\RandomERP\Shortcodes\LocationStockShortcode;
use Socomarca\RandomERP\Compat\MultilocationBlockFix;
use Socomarca\RandomERP\Frontend\ProductPageCustomizer;
use Socomarca\RandomERP\Frontend\ProductStockValidator;
use Socomarca\RandomERP\Frontend\ZeroPriceValidator;

class Plugin {
    
    private static $instance = null;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->init();
    }
    
    private function init() {
        
        
        $this->initializeComponents();
        
        
        $this->registerHooks();
        
    }
    
    private function initializeComponents() {
        
        
        new AuthAjaxHandler();
        new EntityAjaxHandler();
        new CategoryAjaxHandler();
        new ProductAjaxHandler();
        new PriceListAjaxHandler();
        new BrandAjaxHandler();
        new WarehouseAjaxHandler();
        new StockAjaxHandler();
        new CombinedAjaxHandler();
        new CartWarehouseSwitchHandler();
        new CronSyncAjaxHandler();
        
        // Inicializar el servicio de cron
        $cronService = new CronSyncService();
        $cronService->init();
        
        
        new AdminPages();
        new CategoryTaxonomyAdmin();
        new LocationMappingAdmin();
        new LocationMappingAjaxHandler();
        new ProductFilterAdmin();

        new DocumentService();

        new LocationStockShortcode();
        new LocationProductFilter();
        new LocationStockFilter();
        new ProductVisibilityFilter();
        new CheckoutShippingFilter();
        new MultilocationBlockFix();
        new ProductPageCustomizer();
        new ProductStockValidator();
        new ZeroPriceValidator();

    }
    
    private function registerHooks() {
        
        register_activation_hook($this->getPluginFile(), [$this, 'activate']);
        
        
        register_deactivation_hook($this->getPluginFile(), [$this, 'deactivate']);
        
        
        register_uninstall_hook($this->getPluginFile(), [__CLASS__, 'uninstall']);
        
        
        add_filter('plugin_action_links_' . plugin_basename($this->getPluginFile()), [$this, 'addSettingsLink']);
    }
    
    public function activate() {
        
        $this->createDatabaseTables();
        $this->setDefaultOptions();
        
    }
    
    public function deactivate() {
        
        $this->cleanupScheduledTasks();
        
    }
    
    public static function uninstall() {
        
        self::removePluginData();
        
    }
    
    private function createDatabaseTables() {
        
        
    }
    
    private function setDefaultOptions() {
        
        add_option('sm_operation_mode', 'development');
        add_option('sm_dev_api_url', 'http://seguimiento.random.cl:3003');
        add_option('sm_prod_api_url', '');
        add_option('sm_api_user', 'demo@random.cl');
        add_option('sm_api_password', 'd3m0r4nd0m3RP');
        add_option('sm_production_token', '');
        add_option('sm_company_code', '01');
        add_option('sm_company_rut', '134549696');
    }
    
    private function cleanupScheduledTasks() {
        
        wp_clear_scheduled_hook('sm_sync_entities');
        wp_clear_scheduled_hook('sm_sync_products');
        wp_clear_scheduled_hook('sm_sync_categories');
    }
    
    private static function removePluginData() {
        
        delete_option('sm_api_url');
        delete_option('sm_api_user');
        delete_option('sm_api_password');
        delete_option('sm_company_code');
        delete_option('sm_company_rut');
        delete_option('random_erp_token');
        
        
        delete_option('sm_entities_cache');
        delete_option('sm_products_cache');
        delete_option('sm_total_created_users');
        delete_option('sm_total_updated_users');
        delete_option('sm_total_created_products');
        delete_option('sm_total_updated_products');
    }
    
    private function getPluginFile() {
        return plugin_dir_path(__DIR__) . 'index.php';
    }
    
    public function getVersion() {
        return '1.0.0';
    }
    
    public function getPluginName() {
        return 'Socomarca Random ERP Sync for WooCommerce';
    }
    
    public function addSettingsLink($links) {
        $settings_link = '<a href="' . admin_url('admin.php?page=socomarca') . '">Ajustes</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
}
