# GEMINI.md

Este documento contiene la información esencial para interactuar con el proyecto **Socomarca Random ERP Sync for WooCommerce**.

## Descripción del Proyecto
Este es un plugin de WordPress diseñado para sincronizar datos entre **WooCommerce** y **Random ERP**. El plugin maneja la sincronización de usuarios, categorías, productos y listas de precios, integrándose con **B2B King** para funcionalidades de precios B2B.

## Tecnologías Principales
- **WordPress**: (Probado hasta 6.8)
- **WooCommerce**: Requerido
- **B2B King**: Requerido para precios B2B
- **PHP**: 8.2+
- **Framework de Testing**: Pest PHP

## Arquitectura
- El código fuente reside en `src/`, estructurado bajo el namespace `Socomarca\RandomERP\`.
- **Services**: Lógica de negocio principal (`src/Services/`).
- **Handlers**: Manejadores de AJAX (`src/Ajax/`).
- **Admin**: Lógica de paneles administrativos (`src/Admin/`).
- **Frontend**: Lógica del lado del cliente (`src/Frontend/`).
- **Tests**: Suite de pruebas en `tests/` (Unitarias y de Integración).

## Comandos Útiles

### Docker
- Iniciar: `docker-compose up -d`
- Acceder a PHP: `docker-compose exec app bash`
- Ver logs: `docker-compose logs -f`

### Testing
Ejecutar todos los tests:
```bash
./vendor/bin/pest
```
Ejecutar tests específicos:
```bash
./vendor/bin/pest tests/Unit/
./vendor/bin/pest tests/Integration/
```

## Desarrollo y Convenciones
- NUNCA hagas commit o push 
- Ejecuta todos los comandos de `php artisan` dentro del contenedor con:
  `docker exec -it mailmaniacl-app-1 php artisan <comando>` (ajustar según el contenedor).
- Todo CSS/JS debe estar en la carpeta `assets/` e integrarse correctamente.
- Sigue la estructura de namespaces `Socomarca\RandomERP` para nuevo código en `src/`.
- **Regla de estilo**: Los títulos y encabezados deben usar "Sentence case" en español.
- **Estructura**: Los nombres de archivos/directorios deben ser alfanuméricos.
